﻿namespace SuperApp
{
    public class Person
    {
        public string FirstName { get; set; }
    }
}